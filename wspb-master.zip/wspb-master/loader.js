(function(){if(window.LDR===undefined){window.LDR={};}else{return;}

var load_conf = {
  'comet.js': [
	//"neworder\\.php\\?package=4$"
  ],
  'wspb.js': [
  ]
};

LDR.path = self_path('loader.js');
LDR.reg_match = regex_matched;
LDR.load = load_LazyLoad();
LDR.load.js(load_list());

function load_list()
{
	var rets = [];
	for (var name in load_conf) {
		if (load_conf.hasOwnProperty(name)) {
			var patts = load_conf[name];
			if (LDR.reg_match(window.location.href, patts)) {
				rets.push(LDR.path+name);
			}
		}
	}
	return rets;
}


function regex_matched(e,r)
{if(e)for(var n in r){var t=r[n],i=new RegExp(t,"i");if(i.test(e))return parseInt(n,10)+1}return 0}

function self_path(t)
{var e=function(){if(document.currentScript)return document.currentScript.src;var e,n,r=function(e,n){var r,u,c,i=e.length;for(r=0;i>r;r++)if(c=null,void 0!==e[r].getAttribute.length&&(c=e[r].getAttribute(n,2)),c&&(u=c,u=u.split("?")[0].split("/").pop(),u===t))return c};return e=document.getElementsByTagName("script"),n=r(e,"src"),n||(e=document.getElementsByTagName("meta"),n=r(e,"content")),n?n:""}(),n=e.substring(0,e.lastIndexOf("/"))+"/";return n}

function load_LazyLoad()
{return (function(j){var g,h,b={},e=0,f={css:[],js:[]},m=j.styleSheets;function l(q,p){var r=j.createElement(q),o;for(o in p){if(p.hasOwnProperty(o)){r.setAttribute(o,p[o])}}return r}function i(o){var r=b[o],s,q;if(r){s=r.callback;q=r.urls;q.shift();e=0;if(!q.length){s&&s.call(r.context,r.obj);b[o]=null;f[o].length&&k(o)}}}function c(){var o=navigator.userAgent;g={async:j.createElement("script").async===true};(g.webkit=/AppleWebKit\//.test(o))||(g.ie=/MSIE/.test(o))||(g.opera=/Opera/.test(o))||(g.gecko=/Gecko\//.test(o))||(g.unknown=true)}var n={Version:function(){var o=999;if(navigator.appVersion.indexOf("MSIE")!=-1){o=parseFloat(navigator.appVersion.split("MSIE")[1])}return o}};function k(A,z,B,w,s){var u=function(){i(A)},C=A==="css",q=[],v,x,t,r,y,o;g||c();if(z){z=typeof z==="string"?[z]:z.concat();if(C||g.async||g.gecko||g.opera){f[A].push({urls:z,callback:B,obj:w,context:s})}else{for(v=0,x=z.length;v<x;++v){f[A].push({urls:[z[v]],callback:v===x-1?B:null,obj:w,context:s})}}}if(b[A]||!(r=b[A]=f[A].shift())){return}h||(h=j.head||j.getElementsByTagName("head")[0]);y=r.urls;for(v=0,x=y.length;v<x;++v){o=y[v];if(C){t=g.gecko?l("style"):l("link",{href:o,rel:"stylesheet"})}else{t=l("script",{src:o});t.async=false}t.className="lazyload";t.setAttribute("charset","utf-8");if(g.ie&&!C&&n.Version()<10){t.onreadystatechange=function(){if(/loaded|complete/.test(t.readyState)){t.onreadystatechange=null;u()}}}else{if(C&&(g.gecko||g.webkit)){if(g.webkit){r.urls[v]=t.href;d()}else{t.innerHTML='@import "'+o+'";';a(t)}}else{t.onload=t.onerror=u}}q.push(t)}for(v=0,x=q.length;v<x;++v){h.appendChild(q[v])}}function a(q){var p;try{p=!!q.sheet.cssRules}catch(o){e+=1;if(e<200){setTimeout(function(){a(q)},50)}else{p&&i("css")}return}i("css")}function d(){var p=b.css,o;if(p){o=m.length;while(--o>=0){if(m[o].href===p.urls[0]){i("css");break}}e+=1;if(p){if(e<200){setTimeout(d,50)}else{i("css")}}}}return{css:function(q,r,p,o){k("css",q,r,p,o)},js:function(q,r,p,o){k("js",q,r,p,o)}}})(this.document);}

})();
