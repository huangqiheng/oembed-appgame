<?php
require_once __DIR__ . '/wspb.php';

if (is_async_hardwork()) {
	$save_file = $_POST['file'];
	$src_data = file_get_contents($save_file);
	$buying = json_decode($src_data, true);
	$buying['save_file'] = $save_file;

	if (!array_key_exists('buy_params', $buying)) {
		log_error('async file error', array($buying, $save_file, $src_data));
		exit;
	}

	$buy_parmas = $buying['buy_params'];
	$buy_res =  buy_product($buy_parmas);

	if (empty($buy_res)) {
		log_error('async buy_product error!', $buying);
		blackbox_error($buy_parmas['transactionID'], 'asyncBuy');
	} else {
		log_success('async buy_product success!', $buying);
		blackbox_success($buy_parmas['transactionID'], 'asyncBuy');
		unlink($save_file);
	}
	exit;
}

function login_buy_product($params)
{
	if (!preg_match('/#(\w+)#$/m', $params['item_name'], $matchs)) {
		log_error('buy_product:: invalid item name, username not found.', $params);
		return false;
	}
	$user_name = $matchs[1];
	$user_info = user_info($user_name);

	if (empty($user_info)) {
		log_error('buy_product:: login err, but continue buy product without token.' , array($params, $user_name));
	}

	$prods = get_vip_products($user_name);
	$gross = intval($params['payment_gross']);
	$product_id = null;
	foreach($prods as $prod) {
		if ($gross == intval($prod['price'])) {
			$product_id = $prod['productID'];
			break;
		}
	}
	if (empty($product_id)) {
		log_error('buy_product:: product id not matched', array($params, $user_name, $prods));
		return false;
	}

	$ins_info = getuser_from_name($user_name);
	$ins_id = $ins_info['id'];

	$params['username'] = $user_name;
	$params['instagramID'] = $ins_id;
	$params['productID'] = $product_id;
	return buy_vip_product($params);
}

function buy_product($params)
{
	if (empty($params)) {
		log_error('buy_product inputed params is empty');
		return false;
	}

	$check_items = array('username','instagramID','productID','from','transactionID','validationData');
	$required_items = array();

	if (!array_key_exists('isPrivateInsUser', $params)) {
		$params['isPrivateInsUser'] = false;
	}

	foreach($check_items as $item) {
		if (!array_key_exists($item, $params)) {
			array_push($required_items, $item);
		}
	}

	if (!empty($required_items)) {
		log_error('buy_vip_product need params', array($params, $required_items));
		return false;
	}

	return buy_vip_product($params);
}

