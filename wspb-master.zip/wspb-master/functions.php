<?php
require_once 'config.php';
require_once 'log.php';


function keys_exists($keys, $array)
{
	if (empty($array)) {
		return false;
	}
	foreach($keys as $key) {
	    if (!array_key_exists($key, $array))
	    	return false;
	}
	return true;
}


/**************** async call php script ****************/
define('ME_USERAGENT', 'async_routine');
define('CURL_DEBUG', false);

//is included? or call by cronb/web
function is_direct_called($full_name=__FILE__)
{
	$real_script = realpath($_SERVER['SCRIPT_FILENAME']);
        return ($real_script === $full_name);
}

function do_hard_work($response)
{
	set_time_limit(0); 
	ignore_user_abort(true);
	header("Connection: close");
	header("Content-Length: " . mb_strlen($response));
	echo $response;
	flush();
}

function is_async_hardwork($full_name=__FILE__)
{
	if (is_async_called($full_name)) {
		do_hard_work('ACCEPT');
		return true;
	}
	return false;
}

function is_async_called($full_name=__FILE__)
{
	return (!is_direct_called($full_name) && async_call());
}

function is_async_direct_called($full_name=__FILE__)
{
	return (is_direct_called($full_name) && async_call());
}


function async_call($script_path=null, $data=null)
{
	defined('ASYNC_USERAGENT') or define('ASYNC_USERAGENT', 'async_call_client');
	defined('ASYNC_HOST') or define('ASYNC_HOST', 'fansup.mobi');
	defined('ASYNC_PORT') or define('ASYNC_PORT', '80');
	defined('ASYNC_HTTPS') or define('ASYNC_HTTPS', true);

	if ($script_path === null) {
		return (@$_SERVER['HTTP_USER_AGENT'] === ASYNC_USERAGENT);
	}

	$headers = array(
		'Host: '.ASYNC_HOST,
		'User-Agent: '.ASYNC_USERAGENT,
	);
	
	$curl_opt = array(
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_PORT => ASYNC_PORT, 
		CURLOPT_RETURNTRANSFER => 1,
		CURLOPT_NOSIGNAL => 1,
		CURLOPT_CONNECTTIMEOUT_MS => 7000,
		CURLOPT_TIMEOUT_MS =>  7000,
	);

	if (ASYNC_HTTPS) {
		$url = 'https://127.0.0.1:'.ASYNC_PORT.$script_path;
		$curl_opt[CURLOPT_URL] = $url;
		$curl_opt[CURLOPT_SSL_VERIFYHOST] = false;
		$curl_opt[CURLOPT_SSL_VERIFYPEER] = false;
	} else {
		$url = 'http://127.0.0.1:'.ASYNC_PORT.$script_path;
		$curl_opt[CURLOPT_URL] = $url;
	}

	if ($data) {
		$curl_opt[CURLOPT_POST] = 1;
		$curl_opt[CURLOPT_POSTFIELDS] = http_build_query($data);
	}

	$ch = curl_init();
	curl_setopt_array($ch, $curl_opt);
	$res = curl_exec($ch);

        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_errno($ch);
        curl_close($ch);

        if (($err) || ($httpcode !== 200)) {
		log_error('curl error: ', array('err'=>$err, 'http code'=>$httpcode, 'curl_exec'=>$res, 'curl_opt'=>$curl_opt));

		if ($err == 28) {
			return null;
		} 

                return false;
        }

	return ('ACCEPT'===$res);
}

function save_buying($buy_params, $order, $invoice)
{
	$path = dirname(__FILE__).'/data/buying';
	if (!file_exists($path)) {
		mkdir($path);
	}
	$file_name = $path . '/' . $invoice['txn_id'] . '.db';
	$data = array(
		'buy_params' => $buy_params, 
		'order' => $order, 
		'invoice' => $invoice
	);
	file_put_contents($file_name, json_encode($data));
	return $file_name;
}


function is_valid_name ($name){
 	$filter = "^[A-Za-z][a-zA-Z0-9\-\_\.@]{5,}$";
	return preg_match("~" . $filter . "~iU", $name) ? true: false;
}

function get_from_instagram($url)
{
	$res = curl_get_content($url);

	if (empty($res)) {
		return false;
	}

	$result = json_decode($res, true);

	$code = @$result['meta']['code'];

	if ($code == 429) {
		return null;
	}
	
	if ($code !== 200) {
		return false;
	}

	$targets = @$result['data'];

	if (empty($targets)) {
		return false;
	}

	return $targets;
}

function api_open_mmc()
{
	$mem = new Memcached();
	$ss = $mem->getServerList();
	if (empty($ss)) {
		$mem->addServer(MEMC_HOST, MEMC_PORT);
	}
	return $mem;
}

function begin_cache($key)
{
	$mem = api_open_mmc();
	return $mem->get($key);
}

function end_cache($key, $value, $sec=3600*24*30)
{
	$mem = api_open_mmc();
	$is_ok = $mem->set($key, $value, $sec);
	return $value;
}

function file_cache($url, $res=null)
{
	$path = dirname(__FILE__).'/data/ins-cache';
	if (!file_exists($path)) {
		mkdir($path);
	}
	$file_name = $path . '/' . md5($url) . '.json';

}

function getuser_from_mundimago($username) 
{
	$start_time = microtime(true);
	if ($result = begin_cache('ins_'.$username)) return $result; 

	$user = urldecode($username);
	$url = 'http://www.mundimago.com/profile/side-data/'.$user.'/user_photos';

	$referer = 'http://www.mundimago.com/profile/'.$user;
	$res = curl_get_content($url, $referer);

	$target = array();

	if (preg_match('|profileid="(\d+)"\>|', $res, $matchs)) {
		$target['id'] = $matchs[1];
	}

	if (preg_match('|\<h1\>\s+\<span\>(.+)\</span\>|im', $res, $matchs)) {
		$target['full_name'] = $matchs[1];
	}

	if (preg_match('|background.{5,8}url\((.+)\) no-repeat|', $res, $matchs)) {
		$target['profile_picture'] = $matchs[1];
	}

	if (empty($target)) {
		return false;
	}

	$target['username'] = $user;
	trace_block($target, $url, $start_time);
	return end_cache('ins_'.$username, $target);
}

function trace_block(&$parent, $caption, $start_time=null)
{
	$res = array(
		'caption' => $caption,
		'timestamp' => date('Y-m-d H:i:s')
	);

	$start_time and ($res['exec_time'] = microtime(true) - $start_time);

	if (!array_key_exists('trace', $parent)) {
		$parent['trace'] = array();
		array_push($parent['trace'], $res);
	} else {
		array_push($parent['trace'], $res);
	}
		
	return $res;
}

function getuser_from_name($username)
{
	$res = null;
	$res or ($res = getuser_from_mundimago($username));
	$res or ($res = getuser_from_instagram($username));
	return $res;
}

function getuser_from_instagram($username)
{
	$start_time = microtime(true);
	if ($result = begin_cache('ins_'.$username)) return $result; 

	$user = urldecode($username);
	global $INS_APIS;

	$target = null;
	foreach($INS_APIS as $api_key) {
		$url = 'https://api.instagram.com/v1/users/search?' . $api_key. '&q=' . $user;
		$targets = get_from_instagram($url);

		//This mean returned 429
		if ($targets === null) {
			continue;
		}

		if ($targets === false) {
			break;
		}

		foreach($targets as $item) {
			if ($item['username'] === $user) {
				$target = $item;
				trace_block($target, $url, $start_time);
				break 2;
			}
		}
	}

	if (empty($target)) {
		return false;
	}

	return end_cache('ins_'.$username, $target);
}

function getuser_from_id($userid)
{
	$user = urldecode($userid);
	$url = 'https://api.instagram.com/v1/users/'.$user.'/?client_id='.INS_CLIENT_ID;
	if ($result = begin_cache($url)) return $result; 

	$targets = get_from_instagram($url);

	if (empty($targets)) {
		return false;
	}

	if (!array_key_exists('id', $targets)) {
		return false;
	}

	$target = $targets;
	$res_user = $target['id'];

	if ($res_user !== $user) {
		return false;
	}

	return end_cache($url, $target);
}

function okres($data)
{
	$res = array();
	$res['status'] = 'ok';
	$res['data'] = $data;
	return jsonp($res);

}

function errres($msg)
{
	$res = array();
	$res['status'] = 'error';
	$res['error'] = $msg;
	return jsonp($res);
}

function is_valid_jsonp_callback($subject)
{
	$identifier_syntax = '/^[$_\p{L}][$_\p{L}\p{Mn}\p{Mc}\p{Nd}\p{Pc}\x{200C}\x{200D}]*+$/u';
	$reserved_words = array('break', 'do', 'instanceof', 'typeof', 'case',
			'else', 'new', 'var', 'catch', 'finally', 'return', 'void', 'continue', 
			'for', 'switch', 'while', 'debugger', 'function', 'this', 'with', 
			'default', 'if', 'throw', 'delete', 'in', 'try', 'class', 'enum', 
			'extends', 'super', 'const', 'export', 'import', 'implements', 'let', 
			'private', 'public', 'yield', 'interface', 'package', 'protected', 
			'static', 'null', 'true', 'false');
	return preg_match($identifier_syntax, $subject)
		&& ! in_array(mb_strtolower($subject, 'UTF-8'), $reserved_words);
}

function jsonp($data)
{
	header('content-type: application/json; charset=utf-8');
	$json = json_encode($data);
	if(!isset($_GET['callback']))
	    return $json;
	if(is_valid_jsonp_callback($_GET['callback']))
	    return "{$_GET['callback']}($json)";
	return false;
}

function curl_get_content($url, $referer=null, $user_agent=null, $conn_timeout=7, $timeout=5)
{
	$headers = array(
		"Accept: application/json",
		"Accept-Encoding: deflate,sdch",
		"Accept-Charset: utf-8;q=1"
		);
	if ($user_agent === null) {
		$user_agent = 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36';
	}
	$headers[] = $user_agent;

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $conn_timeout);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);

	if ($referer) {
		curl_setopt($ch, CURLOPT_REFERER, $referer);
	}
	curl_setopt($ch, CURLOPT_COOKIEJAR, '/tmp/cookies.txt');



	$res = curl_exec($ch);
	$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	$err = curl_errno($ch);
	curl_close($ch);

	if (($err) || ($httpcode !== 200)) {
		return null;
	}
	return $res;
}
function curl_post_content($url, $data, $user_agent=null, $conn_timeout=7, $timeout=5)
{
	$headers = array(
		'Accept: application/json',
		'Accept-Encoding: deflate',
		'Accept-Charset: utf-8;q=1'
		);
	if ($user_agent === null) {
		$user_agent = 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36';
	}
	$headers[] = $user_agent;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $conn_timeout);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
	if ($data) {
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
	}
	$res = curl_exec($ch);
	$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	$err = curl_errno($ch);
	curl_close($ch);
	if (($err) || ($httpcode !== 200)) {
		return null;
	}
	return $res;
}

