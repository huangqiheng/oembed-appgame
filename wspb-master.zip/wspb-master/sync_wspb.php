<?php
require_once __DIR__ . '/log.php';

function exec_buy_product($invoice, $order)
{
	if (!array_key_exists('from', $order)) {
		defined('WSPB_FROM') or define('WSPB_FROM', 'fansup.mobi');
		$order['from'] = WSPB_FROM;
	}

	$order = format_order($order);
	$invoice = format_invoice($invoice);

	$ins = $order['instagram'];
	$pkg = $order['order_package'];

	blackbox_ipn($invoice['txn_id'], $ins['username'], $pkg['productID'], $pkg['price']);

	$buy_params = array(
		'username' => $ins['username'],
		'instagramID' => $ins['id'],
		'productID' => $pkg['productID'],
		'from' => $order['from'],
		'validationData' => $invoice['invoice'],
		'transactionID' => $invoice['txn_id']);


	$save_file = save_buying($buy_params, $order, $invoice);

	if ($save_file === false) {
		log_error('save_buying error' , array($buy_params, $order, $invoice));
	}

	$async_ok = do_async_call('/wspb/buy.php', array('file'=>$save_file));
	if (empty($async_ok)) {
		log_error('async_call error' , array($buy_params, $order, $invoice));
	}

	return TRUE;
}

function format_order($order)
{
	$res = array();
	$res['instagram'] = $order['instagram'];
	$res['order_package'] = $order['order_package'];
	$res['from'] = $order['from'];
	$res['email'] = $order['email'];
	$res['order_title'] = $order['order_title'];

	$res['serialize'] = base64_encode(serialize($order)); 
	return $res;
}

function format_invoice($invoice)
{
	$res = array();
	$res['invoice'] = $invoice['invoice'];
	$res['txn_id'] = $invoice['txn_id'];
	$res['business'] = $invoice['business'];
	$res['receiver_email'] = $invoice['receiver_email'];
	$res['payer_email'] = $invoice['payer_email'];
	$res['payment_type'] = $invoice['payment_type'];
	$res['item_name'] = $invoice['item_name'];
	$res['quantity'] = $invoice['quantity'];
	$res['mc_currency'] = $invoice['mc_currency'];
	$res['mc_gross'] = $invoice['mc_gross'];
	$res['mc_fee'] = $invoice['mc_fee'];
	$res['tax'] = $invoice['tax'];
	$res['shipping'] = $invoice['shipping'];

	$res['serialize'] = base64_encode(serialize($invoice)); 
	return $res;
}

function do_async_call($script_path=null, $data=null)
{
	$res = async_call($script_path, $data);
	if ($res === null) {
		log_error('redo async_call' , array($script_path, $data));
		$res = async_call($script_path, $data);
	}
	return $res;
}

function async_call($script_path=null, $data=null)
{
	defined('ASYNC_USERAGENT') or define('ASYNC_USERAGENT', 'async_call_client');
	defined('ASYNC_HOST') or define('ASYNC_HOST', 'fansup.mobi');
	defined('ASYNC_PORT') or define('ASYNC_PORT', '80');
	defined('ASYNC_SSLPORT') or define('ASYNC_SSLPORT', '443');
	defined('ASYNC_HTTPS') or define('ASYNC_HTTPS', true);

	if ($script_path === null) {
		return (@$_SERVER['HTTP_USER_AGENT'] === ASYNC_USERAGENT);
	}

	$headers = array(
		'Host: '.ASYNC_HOST,
		'User-Agent: '.ASYNC_USERAGENT,
	);
	
	$curl_opt = array(
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_PORT => ASYNC_PORT, 
		CURLOPT_RETURNTRANSFER => 1,
		CURLOPT_NOSIGNAL => 1,
		CURLOPT_CONNECTTIMEOUT_MS => 7000,
		CURLOPT_TIMEOUT_MS =>  7000,
	);

	if (ASYNC_HTTPS) {
		$url = 'https://127.0.0.1:'.ASYNC_SSLPORT.$script_path;
		$curl_opt[CURLOPT_URL] = $url;
		$curl_opt[CURLOPT_PORT] = ASYNC_SSLPORT;
		$curl_opt[CURLOPT_SSL_VERIFYHOST] = false;
		$curl_opt[CURLOPT_SSL_VERIFYPEER] = false;
	} else {
		$url = 'http://127.0.0.1:'.ASYNC_PORT.$script_path;
		$curl_opt[CURLOPT_URL] = $url;
	}

	if ($data) {
		$curl_opt[CURLOPT_POST] = 1;
		$curl_opt[CURLOPT_POSTFIELDS] = http_build_query($data);
	}

	$ch = curl_init();
	curl_setopt_array($ch, $curl_opt);
	$res = curl_exec($ch);

        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_errno($ch);
        curl_close($ch);

        if (($err) || ($httpcode !== 200)) {
		log_error('curl error: ', array('err'=>$err, 'http code'=>$httpcode, 'curl_exec'=>$res, 'curl_opt'=>$curl_opt));

		if ($err == 28) {
			return null;
		} 

                return false;
        }

	return ('ACCEPT'===$res);
}

function save_buying($buy_params, $order, $invoice)
{
	$path = dirname(__FILE__).'/data/buying';
	if (!file_exists($path)) {
		mkdir($path);
	}
	$file_name = $path . '/' . $invoice['txn_id'] . '.db';
	$data = array(
		'buy_params' => $buy_params, 
		'order' => $order,
		'invoice' => $invoice
	);

	if (false === file_put_contents($file_name, prety_json($data))) {
		return false;
	}

	return $file_name;
}

