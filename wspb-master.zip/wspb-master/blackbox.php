<?php
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/log.php';

use Mailgun\Mailgun;

$begin_time = time();

$blackbox = DATA_PATH .'/blackbox.db';
$blackbox_new = DATA_PATH .'/blackbox.new.db';
$blackbox_all = DATA_PATH .'/blackbox.all.db';

if (!file_exists($blackbox)) die();
rename($blackbox, $blackbox_new);

$msg = file_get_contents($blackbox_new);
if (empty($msg)) die();

error_log($msg, 3, $blackbox_all);
$total_msg = file_get_contents($blackbox_all);
unlink($blackbox_new);

//make report
$current_prices = get_amount($msg);
$total_prices = get_amount($total_msg);
$month_list = get_statistics($total_msg);
$use_time = time() - $begin_time;
$mail_text = $msg . PHP_EOL.  
	'today amount: $' . $current_prices . PHP_EOL . 
	'total amount: $' . $total_prices. PHP_EOL . 
	'execute secs: ' .  $use_time. PHP_EOL . PHP_EOL . $month_list;

//zip file 
$new_zipfile = gzCompressFile($blackbox_all);

//send the report
$mg = new Mailgun(MAILGUN_PRIKEY);
$mg->sendMessage('fansup.mobi', 
    array(
	'from'    => 'admin@fansup.mobi', 
	'to'      => 'huangqiheng@gmail.com', 
	'subject' => 'fansup blackbox: '.date("Y-m-d H:i:s"), 
	'text'    => $mail_text),
    array('attachment' => array(
	array('filePath' => '@'.$new_zipfile, 'remoteName'=>'blackbox.gz')
    ))
);
unlink($new_zipfile);

function gzCompressFile($source, $level = 9)
{ 
	$dest = $source . '.gz'; 
	$mode = 'wb' . $level; 
	$error = false; 
	if ($fp_out = gzopen($dest, $mode)) 
	{ 
		if ($fp_in = fopen($source,'rb')) { 
			while (!feof($fp_in)) 
				gzwrite($fp_out, fread($fp_in, 1024 * 512)); 
			fclose($fp_in); 
		} else {
			$error = true; 
		}
		gzclose($fp_out); 
	} else {
		$error = true; 
	}

	if ($error)
		return false; 
	else
		return $dest; 
} 

function get_amount($log_text)
{
	$prices = 0.0;
	if (empty($log_text)) {
		return $prices;
	}

	if (preg_match_all('/,\s+(\d+(?:\.\d+)?)$/m', $log_text, $matchs)) {
		foreach($matchs[1] as $item) {
			$prices += floatval($item);
		}
	}
	return $prices;
}

function get_statistics($log_text)
{
	if (preg_match_all('/(^[0-9]{4}-[0-9]{2}-[0-9]{2}).+?([0-9]+(\.[0-9]+)?$)/m', $log_text, $matchs)) {
		$datas = array();
		foreach($matchs[1] as $index=>$date_key) {
			$price = floatval($matchs[2][$index]);
			if (array_key_exists($date_key, $datas)) {
				$datas[$date_key] += $price;
			} else {
				$datas[$date_key] = $price;
			}
		}
		
		$keys = array_reverse(array_keys($datas));
		$values = array_values($datas);
		$max_value = max($values);
		$min_value = min($values);
		$res_str = '';
		$max_unit = 40;
		foreach($keys as $key) {
			$offset = intval($datas[$key] - $min_value);
			$value = intval(($offset / ($max_value-$min_value)) * $max_unit);
			empty($value) and ($value=1);
			$left = $max_unit - $value;
			$res_str .= $key . ' ' . str_repeat('※', $value) . str_repeat('  ', $left) . '$' . $datas[$key] . PHP_EOL;
		}
		return $res_str;
	}
	return '';
}

