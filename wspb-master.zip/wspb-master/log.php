<?php

/**************************************
log box
**************************************/
function log_local($filename, $msg, $data=null)
{
	$logfile = dirname(__FILE__).'/data/'.$filename;
	$sav_data = array();
	$sav_data['time'] = date("Y-m-d H:i:s");
	$sav_data['message'] = $msg; 
	$sav_data['data'] = $data; 
	$log_msg = prety_json($sav_data) . PHP_EOL;
	error_log($log_msg, 3, $logfile);
}

function log_success($msg, $data=null)
{
	log_local('success.db', $msg, $data);
}

function log_error($msg, $data=null)
{
	log_local('error.db', $msg, $data);
}


function prety_json($obj)
{
        return indent_json(json_encode($obj));
}

function indent_json($json)
{
        $result      = '';
        $pos         = 0;
        $strLen      = strlen($json);
        $indentStr   = '  ';
        $newLine     = "\n";
        $prevChar    = '';
        $outOfQuotes = true;

        for ($i=0; $i<=$strLen; $i++) {

                // Grab the next character in the string.
                $char = substr($json, $i, 1);

                // Are we inside a quoted string?
                if ($char == '"' && $prevChar != '\\') {
                        $outOfQuotes = !$outOfQuotes;

                        // If this character is the end of an element,
                        // output a new line and indent the next line.
                } else if(($char == '}' || $char == ']') && $outOfQuotes) {
                        $result .= $newLine;
                        $pos --;
                        for ($j=0; $j<$pos; $j++) {
                                $result .= $indentStr;
                        }
                }

                // Add the character to the result string.
                $result .= $char;

                // If the last character was the beginning of an element,
                // output a new line and indent the next line.
                if (($char == ',' || $char == '{' || $char == '[') && $outOfQuotes) {
                        $result .= $newLine;
                        if ($char == '{' || $char == '[') {
                                $pos ++;
                        }

                        for ($j = 0; $j < $pos; $j++) {
                                $result .= $indentStr;
                        }
                }

                $prevChar = $char;
        }

        return $result;
}

/**************************************
black box
**************************************/

function blackbox_ipn($transactionID, $username, $productID, $price)
{
	blackbox_message('ipnAccept', $transactionID, $username, $productID, $price);
}

function blackbox_error($transactionID, $caption)
{
	blackbox_message('commitError', $transactionID, $caption);
}

function blackbox_success($transactionID, $caption)
{
	blackbox_message('commitSuccess', $transactionID, $caption);
}

function blackbox_message()
{
	$logfile = dirname(__FILE__).'/data/blackbox.db';

	$arg_list = func_get_args();
	array_unshift($arg_list, date("Y-m-d H:i:s"));
	$log_msg = implode(",\t", $arg_list) . PHP_EOL;

	error_log($log_msg, 3, $logfile);
}


