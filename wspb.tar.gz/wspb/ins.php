<?php
require_once 'functions.php';

switch($_GET['cmd']) {
	case 'user': 	die(handle_get_userid());
	default:  	die(errres('cmd error'));
}

function handle_get_userid()
{
	if (isset($_GET['username'])) {
		$target = getuser_from_name($_GET['username']);
	} else 
	if (isset($_GET['userid'])) {
		$target = getuser_from_id($_GET['userid']);
	} else {
		return errres('cmd error');
	}

	if (empty($target)) {
		return errres('user not match');
	}

	return okres($target);
}


?>
