<?php
require_once 'functions.php';

function on_transaction_complete($invoice)
{
	exec_buy_product($invoice);
}

function on_amount_query($params)
{
	return okres($params);
}

function on_confirm_pay($params)
{

}

function on_redirect_pay($params)
{
?>
<!DOCTYPE html>
<html><head></head><body>
<script type="text/javascript">

</script>
</body></html>
<?php
}

/*----------------------------------------------------------
		router
----------------------------------------------------------*/

if (keys_exists(array('ipn_track_id', 'txn_id'), $_POST)) {
	if ($invoice = is_ipn_complete())  {
		on_transaction_complete($invoice);
	}
	exit();
}

if (keys_exists(array('item','quat','user','chan'), $_GET)) {
	$params = append_params(array(
		'item_name' => $_GET['item'], 
		'quantity' => $_GET['quat'],
		'username' => $_GET['user'],
		'channel' => $_GET['chan']
	));

	($cmd=@$_GET['cmd']) or ($cmd = 'pay');
	switch($cmd) {
		case 'query': 	die(on_amount_query($params));
		case 'pay': 	die(on_confirm_pay($params));
		case 'autopay': die(on_redirect_pay($params));
	}
	exit(errres('cmd error'));
}


/*----------------------------------------------------------
		module functions	
----------------------------------------------------------*/

function append_params($params)
{
	global $prod_prices;

	$item = ucfirst(strtolower($params['item_name'])); 
	if (!array_key_exists($item, $prod_prices)) {
		return false;
	}

	$price = @$prod_prices[$item];
	if (empty($price)) {
		return false;
	}
	$price = floatval($price);

	$quantity = intval($params['quantity']);
	if ($quantity < 1) {
		return false;
	}

	$params['item_name'] = $item;
	$params['price'] = $price;
	$params['quantity'] = $quantity;
	$params['amount'] = $price * $quantity;
	$params['discount'] = 0;

	return $params;
}

function is_ipn_complete()
{
	// Read POST data
	// reading posted data directly from $_POST causes serialization
	// issues with array data in POST. Reading raw POST data from input stream instead.
	$raw_post_data = file_get_contents('php://input');
	$raw_post_array = explode('&', $raw_post_data);
	$myPost = array();
	foreach ($raw_post_array as $keyval) {
		$keyval = explode ('=', $keyval);
		if (count($keyval) == 2)
			$myPost[$keyval[0]] = urldecode($keyval[1]);
	}

	// read the post from PayPal system and add 'cmd'
	$req = 'cmd=_notify-validate';
	if(function_exists('get_magic_quotes_gpc')) {
		$get_magic_quotes_exists = true;
	}
	foreach ($myPost as $key => $value) {
		if($get_magic_quotes_exists == true && get_magic_quotes_gpc() == 1) {
			$value = urlencode(stripslashes($value));
		} else {
			$value = urlencode($value);
		}
		$req .= "&$key=$value";
	}

	if(USE_SANDBOX == true) {
		$paypal_url = "https://www.sandbox.paypal.com/cgi-bin/webscr";
	} else {
		$paypal_url = "https://www.paypal.com/cgi-bin/webscr";
	}

	$ch = curl_init($paypal_url);
	if ($ch == FALSE) {
		return FALSE;
	}

	curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
	curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);

	if(DEBUG == true) {
		curl_setopt($ch, CURLOPT_HEADER, 1);
		curl_setopt($ch, CURLINFO_HEADER_OUT, 1);
	}

	// CONFIG: Optional proxy configuration
	//curl_setopt($ch, CURLOPT_PROXY, $proxy);
	//curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);

	// Set TCP timeout to 30 seconds
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close'));

	// CONFIG: Please download 'cacert.pem' from "http://curl.haxx.se/docs/caextract.html" and set the directory path
	// of the certificate as shown below. Ensure the file is readable by the webserver.
	// This is mandatory for some environments.

	//$cert = __DIR__ . "./cacert.pem";
	//curl_setopt($ch, CURLOPT_CAINFO, $cert);

	$res = curl_exec($ch);
	if (curl_errno($ch) != 0) // cURL error
	{
		DEBUG and log_error("Can't connect to PayPal to validate IPN message: " . curl_error($ch));
		curl_close($ch);
		exit;

	} else {
		// Log the entire HTTP response if debug is switched on.
		DEBUG and log_error("HTTP request of validation request:". curl_getinfo($ch, CURLINFO_HEADER_OUT) ." for IPN payload: $req");
		DEBUG and log_error("HTTP response of validation request: $res");
		curl_close($ch);
	}

	// Inspect IPN validation result and act accordingly

	// Split response headers and payload, a better way for strcmp
	$tokens = explode("\r\n\r\n", trim($res));
	$res = trim(end($tokens));

	if (strcmp ($res, "VERIFIED") == 0) {
		// check whether the payment_status is Completed
		// check that txn_id has not been previously processed
		// check that receiver_email is your PayPal email
		// check that payment_amount/payment_currency are correct
		// process payment and mark item as paid.

		// assign posted variables to local variables
		//$item_name = $_POST['item_name'];
		//$item_number = $_POST['item_number'];
		//$invoice = $_POST['invoice'];
		$payment_status = $_POST['payment_status'];
		//$payment_amount = $_POST['mc_gross'];
		//$payment_currency = $_POST['mc_currency'];
		//$txn_id = $_POST['txn_id'];
		$receiver_email = $_POST['receiver_email'];
		//$payer_email = $_POST['payer_email'];

	    if($payment_status == 'Completed' && $receiver_email == PAYPAL_RECEIVER) {
		return $myPost;
	    }

	} else if (strcmp ($res, "INVALID") == 0) {
		// log for manual investigation
		// Add business logic here which deals with invalid IPN messages
		DEBUG and log_error("Invalid IPN: $req");
		return FALSE;
	}
}



?>
