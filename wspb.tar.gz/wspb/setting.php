<?php
require_once 'functions.php';
require_once 'wspb.php';

function handle_get_prods($username=null)
{
	if (!is_string($username)) {
		$username='anonymity';
	}

	$key = 'prod_' . $username;
	if ($result = begin_cache($key)) { 
		return $result; 
	}

	if (empty($target = get_vip_products($username))) {
		usleep(100000);
		if (empty($target = get_vip_products($username))) {
			return errres('get products failure.');
		}
	}

	return end_cache($key, $target, 300);
}

