<?php
/******* 周期性cron调用 **********
编辑/etc/crontab，添加：
*  *    * * *	www-data /usr/bin/php -q /path/to/file/cron_wspb.php > /dev/null 2>&2
这样就会每分钟调用本脚本一次，is_cron_calling函数是用来检查来自系统cron的调用
*/

require_once __DIR__ . '/buy.php';

$excpt_root = realpath(__DIR__.'/data/buying');

foreach(glob("{$excpt_root}/*.db") as $save_file) 
{
	$src_data = file_get_contents($save_file);

	$buying = json_decode($src_data, true);
	
	if (empty($buying)) {
		log_error('cron file empty', array($save_file, $src_data));
		continue;
	}

	if (!array_key_exists('buy_params', $buying)) {
		log_error('cron need buy_params', array($buying, $save_file, $src_data));
		continue;
	}

	$buy_parmas = $buying['buy_params'];
	$buy_res =  buy_product($buy_parmas);

	if (empty($buy_res)) {
		log_error('cron buy_product run error', array($buying, $save_file, $src_data));
		blackbox_error($buy_parmas['transactionID'], 'cronBuy');
		continue;
	}

	log_success('cron buy_product success!', $buying);
	blackbox_success($buy_parmas['transactionID'], 'cronBuy');
	unlink($save_file);
}

