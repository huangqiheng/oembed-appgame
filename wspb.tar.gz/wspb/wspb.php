<?php
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/proto/FLProtocol.proto.php';
require_once __DIR__ . '/functions.php';

use WebSocket\Client;

global $client, $default_token, $wspb_api_mapper;
$client = new Client(WS_HOST);
$default_token = null;

$wspb_api_mapper = array(
    'PBLoginResult' => PBAPIType::PBAPIType_Login,
    'PBPingResult' =>  PBAPIType::PBAPIType_Ping,
    'PBGetVIPProductsResponse' =>  PBAPIType::PBAPIType_GetVIPProducts,
    'PBBuyVIPProductResponse' =>  PBAPIType::PBAPIType_BuyVIPProduct,
    'null' => null
);

function user_info($user_name)
{
	global $default_token;
	if (!is_valid_name($user_name)) {
		log_error('user_info:: username format error.', $user_name);
		return false;
	}

	$accessToken = null;
	$data = array();
	do {
		$data_file = DATA_PATH . '/' . $user_name;
		if (!file_exists($data_file)) {break;}

		$sav_data = file_get_contents($data_file);
		if(empty($sav_data)) {break;}
		$src_data = json_decode($sav_data, true);
		if(empty($src_data)) {
			log_error('user_info:: file_get_contents succeed but json_decode error.', array($src_data));
			break;
		}
		if (!array_key_exists('last_login', $src_data)) {
			log_error('user_info:: the data from file format error.', array($src_data));
			break;
		}

		$data = $src_data;

		$last_time = intval($src_data['last_login']);
		if ((time() - $last_time) > LOGIN_INTERNAL) {
			$accessToken = $data['accessToken'];
			break;
		}

		$default_token = $data['accessToken'];
		return $data;
	} while (false);


	if (empty($login_res = login($user_name, $accessToken))) {
		log_error("user_info:: login error.", array($user_name, $accessToken));
		return false;
	}

	$userInfo = $login_res->getUserInfo();
	$expInfo = $login_res->getExpInfo();

	$data['last_login'] = time();
	$data['accessToken'] = $login_res->getAccessToken();
	$data['username'] = $userInfo->getUsername();
	$data['coins'] = $userInfo->getCoins();
	$data['enabled'] = $userInfo->getEnabled();
	$data['params'] = $userInfo->getParams();
	$data['enableChat'] = $userInfo->getEnableChat();
	$data['compressed'] = $userInfo->getCompressed();
	$data['boughtAnyBefore'] = $userInfo->getBoughtAnyBefore();
	$data['liveTasks'] = $login_res->getLiveTasks();
	$data['doingTasks'] = $login_res->getDoingTasks();
	$data['startedGifts'] = $login_res->getStartedGifts();
	$data['price'] = $login_res->getPrice();
	$data['earn'] = $login_res->getEarn();
	$data['onlineUserCount'] = $login_res->getOnlineUserCount();
	$data['hackerDealOpen'] = $login_res->getHackerDealOpen();
	$data['level'] = $expInfo->getLevel();
	$data['exp'] = $expInfo->getExp();
	$data['expPrev'] = $expInfo->getExpPrev();
	$data['expNext'] = $expInfo->getExpNext();
	$data['levelUpPrize'] = $expInfo->getLevelUpPrize();
	$data['levelUp'] = $expInfo->getLevelUp();
	$data['unlockEarn'] = $expInfo->getUnlockEarn();
	$data['nextUnlockLevel'] = $expInfo->getNextUnlockLevel();
	$data['nextUnlockEarn'] = $expInfo->getNextUnlockEarn();
	$data['dailyIAPBeginTS'] = $login_res->getDailyIAPBeginTS();
	$data['dailyIAPEndTS'] = $login_res->getDailyIAPEndTS();

	$default_token = $data['accessToken'];
	file_put_contents($data_file, json_encode($data));
	return $data;
}

function buy_vip_product($params)
{
	$cmd = new PBBuyVIPProduct();
	$cmd->setUsername($params['username']);
	$cmd->setInstagramID($params['instagramID']);
	$cmd->setIsPrivateInsUser($params['isPrivateInsUser']);
	$cmd->setProductID($params['productID']);
	$cmd->setFrom($params['from']);
	$cmd->setTransactionID($params['transactionID']);
	$cmd->setValidationData($params['validationData']);

	$prod_res = echo_cmd($cmd, 'PBBuyVIPProductResponse');

	if (empty($prod_res)) {
		log_error('echo_cmd execute error', array($params, $cmd));
		return false;
	}

	return $prod_res;
}

function get_vip_products($user_name)
{
	$cmd = new PBGetVIPProducts();
	$cmd->setUsername($user_name);

	$prod_res = echo_cmd($cmd, 'PBGetVIPProductsResponse');

	if ($prod_res === false) {
		return false;
	}

	$prods = $prod_res->getProducts();
	
	if (empty($prods)) {
		log_error('get_vip_products:: getProducts() return empty.');
	}

	$result = array();
	foreach($prods as $prod) {
		$prod_id = $prod->getProductID();
		if (empty($prod_id)) {
			continue;
		}

		$item = array();
		$item['productID'] = $prod_id;
		$item['productName'] = $prod->getProductName();
		$item['followerCount'] = intval($prod->getFollowerCount());
		$item['price'] = floatval($prod->getPrice());
		array_push($result, $item);
	}

	usort($result, function($a, $b) {
		if ($a['price'] == $b['price']) {
			return 0;
		}
		return ($a['price'] < $b['price']) ? -1 : 1;
	});

	return $result;
}

function login($user_name, $access_token=null)
{
	global $default_token;

	$login = new PBLogin();
	$login->setUsername($user_name);

	if ($access_token) {
		$login->setAccessToken($access_token);
		$default_token = $access_token;
	}

	$login_res = echo_cmd($login, 'PBLoginResult', $access_token);

	return $login_res;
}

function ping($text)
{
	$ping = new PBPing();
	$ping->setPingText($text);
	$ping_recv = echo_cmd($ping, 'PBPingResult');
	if ($ping_recv === false) {
		return false;
	}
	if ($ping_recv === null) {
		return false;
	}
	return $ping_recv->getServerResponse();  
}

function echo_cmd($cmd, $res_type, $acess_token=null)
{
	global $wspb_api_mapper;
	global $default_token;

	if (!array_key_exists($res_type, $wspb_api_mapper)) {
		log_error("echo_cmd:: {$res_type} not supported yet.", $cmd);
		return false;
	}

	$api_type = $wspb_api_mapper[$res_type];

	if (($acess_token === null) && ($default_token)) {
		$acess_token = $default_token;
	}

	$req_msg = gen_message($api_type, $acess_token, $cmd);

	if (empty($msg_recv = echo_msg($req_msg))) { 
		log_error("echo_cmd:: echo_msg exec error", array($cmd, $req_msg));
		return false;
	}

	$err_code = intval($msg_recv->getErrorCode());
	if ($err_code !== PBErrorcode::PBErrorcode_Success) {
		log_error("echo_cmd:: echo_msg result error. errno: " . pb_error($err_code), $msg_recv);
		return null;
	}

	$dec_res = ProtocolBuffers::decode($res_type, $msg_recv->getPayload());

	if (empty($dec_res)) {
		log_error("ProtocolBuffers::decode error", array($err_code, $res_type, $msg_recv));
		return null;
	}

	return $dec_res;
}

function gen_message($api_type, $access_token, $payload)
{
	$index = mt_rand(100, 999999);
	$msg_id = new PBMessageID();
	$msg_id->setAPIType($api_type);
	$msg_id->setIndex($index);

	$req_msg = new PBMessage();
	$req_msg->setMessageID($msg_id);
	if ($access_token) {
		$req_msg->setAccessToken($access_token);
	}
	$req_msg->setPayload($payload->serializeToString());

	return $req_msg;
}

function echo_msg($req_msg)
{
	global $client;
	$rsp_msg = null; $send_ret = null;
	$re_try = false;

	try {
		$send_ret = $client->send($req_msg->serializeToString(), 'binary');
		$rsp_msg = $client->receive(); 
	} catch(ConnectionException $e) {
		log_error('connect error');
		$re_try = true;
	} catch(Exception $e) {
		log_error('echo_msg:: websocket exception: '.$e->getMessage(), array($req_msg, $rsp_msg));
		return false;
	}

	if ($re_try) {
		usleep(100000);
		try {
			$send_ret = $client->send($req_msg->serializeToString(), 'binary');
			$rsp_msg = $client->receive(); 
		} catch(Exception $e) {
			log_error('re echo_msg:: websocket exception: '.$e->getMessage(), array($req_msg, $rsp_msg));
			return false;
		}
	}

	$result = ProtocolBuffers::decode('PBMessage', $rsp_msg);

	return $result;
}


function print_m($msg)
{
	echo "<pre>";
	print_r($msg);
	echo "</pre>";
}

function pb_error($err_code)
{
	if (is_string($err_code)) {
		$err_code = intval($err_code);
	}
	switch ($err_code) {
		case PBErrorcode::PBErrorcode_Success : return 'Success';
		case PBErrorcode::PBErrorcode_UnknownError : return 'UnknownError';
		case PBErrorcode::PBErrorcode_ParamError : return 'ParamError';
		case PBErrorcode::PBErrorcode_AuthError : return 'AuthError';
		case PBErrorcode::PBErrorcode_NotExistError : return 'NotExistError';
		case PBErrorcode::PBErrorcode_Disabled : return 'Disabled';
		case PBErrorcode::PBErrorcode_CoinsNotEnough : return 'CoinsNotEnough';
		case PBErrorcode::PBErrorcode_InvalideIAP : return 'InvalideIAP';
		case PBErrorcode::PBErrorcode_ConnectionClosed : return 'ConnectionClosed';
		default: return 'Unknow PBErrorcode: '.$err_code;
	}
}

function prod_name2id($prod_name)
{
	$prod_name = strtolower($prod_name);
	switch ($prod_name) {
	  case 'regular': return 'com.FansUpInc.VIPProduct.1';
	  case 'professional': return 'com.FansUpInc.VIPProduct.2';
	  case 'premium': return 'com.FansUpInc.VIPProduct.3';
	  case 'celebrity': return 'com.FansUpInc.VIPProduct.4';
	}
	return false;
}


?>
